package com.re.ss12sroucecode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ss12SrouceCodeApplication {

    public static void main(String[] args) {
        SpringApplication.run(Ss12SrouceCodeApplication.class, args);
    }

}
