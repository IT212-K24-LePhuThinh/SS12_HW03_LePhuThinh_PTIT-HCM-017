package com.re.ss12sroucecode.controller;

import com.re.ss12sroucecode.dto.*;
import com.re.ss12sroucecode.service.AccountService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Controller cung cấp REST API cho quy trình đăng ký tài khoản thanh toán và eKYC trực tuyến.
 */
@RestController
@RequestMapping("/api/v1/accounts")
@RequiredArgsConstructor
public class AccountController {

    private final AccountService accountService;

    /**
     * BƯỚC 1: Khởi tạo thông tin đăng ký (SĐT, Email) và gửi OTP.
     * Endpoint: POST /api/v1/accounts/register
     */
    @PostMapping("/register")
    public ResponseEntity<AccountRegistrationResponse> initiateRegistration(
            @Valid @RequestBody AccountRegistrationRequest request) {
        AccountRegistrationResponse response = accountService.initiateRegistration(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    /**
     * BƯỚC 1 (Tiếp tục): Xác thực mã OTP của khách hàng.
     * Endpoint: POST /api/v1/accounts/verify-otp
     */
    @PostMapping("/verify-otp")
    public ResponseEntity<AccountRegistrationResponse> verifyOtp(
            @Valid @RequestBody OtpVerificationRequest request) {
        AccountRegistrationResponse response = accountService.verifyOtp(request);
        return ResponseEntity.ok(response);
    }

    /**
     * BƯỚC 2: Gửi thông tin trích xuất từ căn cước công dân (NFC/OCR).
     * Endpoint: POST /api/v1/accounts/verify-identity
     */
    @PostMapping("/verify-identity")
    public ResponseEntity<AccountRegistrationResponse> verifyIdentity(
            @Valid @RequestBody IdentityVerificationRequest request) {
        AccountRegistrationResponse response = accountService.verifyIdentity(request);
        return ResponseEntity.ok(response);
    }

    /**
     * BƯỚC 3 & 4: So khớp khuôn mặt và tự động kích hoạt tài khoản Core Banking (STP).
     * Endpoint: POST /api/v1/accounts/verify-biometric
     */
    @PostMapping("/verify-biometric")
    public ResponseEntity<AccountRegistrationResponse> verifyBiometric(
            @Valid @RequestBody BiometricVerificationRequest request) {
        AccountRegistrationResponse response = accountService.verifyBiometric(request);
        return ResponseEntity.ok(response);
    }

    /**
     * TRA CỨU: Kiểm tra thông tin trạng thái tiến trình eKYC của tài khoản.
     * Endpoint: GET /api/v1/accounts/{id}/status
     */
    @GetMapping("/{id}/status")
    public ResponseEntity<AccountRegistrationResponse> getAccountStatus(
            @PathVariable("id") Long id) {
        AccountRegistrationResponse response = accountService.getAccountStatus(id);
        return ResponseEntity.ok(response);
    }
}
