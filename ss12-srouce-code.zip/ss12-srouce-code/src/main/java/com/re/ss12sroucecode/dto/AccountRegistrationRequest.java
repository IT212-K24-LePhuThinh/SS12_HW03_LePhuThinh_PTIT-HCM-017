package com.re.ss12sroucecode.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.*;

/**
 * DTO yêu cầu khởi tạo đăng ký tài khoản (Module 1).
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountRegistrationRequest {

    /**
     * Số điện thoại đăng ký.
     * Ràng buộc: Không trống, đúng định dạng số điện thoại Việt Nam (10 chữ số, bắt đầu bằng 03, 05, 07, 08, 09).
     */
    @NotBlank(message = "Số điện thoại không được để trống")
    @Pattern(regexp = "^0(3|5|7|8|9)[0-9]{8}$", message = "Số điện thoại không đúng định dạng nhà mạng Việt Nam (phải gồm 10 chữ số)")
    private String phone;

    /**
     * Địa chỉ email liên lạc.
     * Ràng buộc: Không trống, đúng định dạng email tiêu chuẩn.
     */
    @NotBlank(message = "Email không được để trống")
    @Email(message = "Email không đúng định dạng")
    private String email;
}
