package com.re.ss12sroucecode.dto;

import com.re.ss12sroucecode.enums.KycStatus;
import lombok.*;

/**
 * DTO phản hồi kết quả đăng ký tài khoản và thông tin eKYC (Output).
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountRegistrationResponse {

    private Long id;
    private String phone;
    private String email;
    private KycStatus status;
    private String citizenId;
    private String fullName;
    private String identityMethod;
    private Boolean livenessPassed;
    private Double faceMatchPercentage;
    private String amlStatus;
    private String cifNumber;
    private String accountNumber;
    private String message;
}
