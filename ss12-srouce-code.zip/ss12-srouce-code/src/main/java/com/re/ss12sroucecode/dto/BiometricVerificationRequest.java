package com.re.ss12sroucecode.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.*;

/**
 * DTO yêu cầu xác thực khuôn mặt sinh trắc học (Module 3).
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BiometricVerificationRequest {

    @NotBlank(message = "Số điện thoại không được để trống")
    @Pattern(regexp = "^0(3|5|7|8|9)[0-9]{8}$", message = "Số điện thoại không đúng định dạng")
    private String phone;

    /**
     * Ảnh khuôn mặt dạng chuỗi Base64.
     */
    @NotBlank(message = "Ảnh sinh trắc học không được để trống")
    private String faceImageBase64;

    /**
     * Tham số mock để test kết quả Liveness (true/false) phục vụ môi trường kiểm thử.
     */
    private Boolean mockLivenessPassed;

    /**
     * Tham số mock để test tỷ lệ so sánh trùng khớp khuôn mặt (%) phục vụ môi trường kiểm thử.
     */
    private Double mockFaceMatchPercentage;
}
