package com.re.ss12sroucecode.dto;

import com.re.ss12sroucecode.enums.Gender;
import com.re.ss12sroucecode.enums.IdentityMethod;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.*;

import java.time.LocalDate;

/**
 * DTO yêu cầu gửi thông tin giấy tờ tùy thân CCCD (Module 2).
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IdentityVerificationRequest {

    @NotBlank(message = "Số điện thoại không được để trống")
    @Pattern(regexp = "^0(3|5|7|8|9)[0-9]{8}$", message = "Số điện thoại không đúng định dạng")
    private String phone;

    /**
     * Số CCCD định danh cá nhân 12 chữ số.
     */
    @NotBlank(message = "Số căn cước công dân không được để trống")
    @Pattern(regexp = "^[0-9]{12}$", message = "Số định danh cá nhân (CCCD) phải đúng định dạng 12 chữ số")
    private String citizenId;

    @NotBlank(message = "Họ và tên không được để trống")
    private String fullName;

    @NotNull(message = "Ngày sinh không được để trống")
    private LocalDate dateOfBirth;

    @NotNull(message = "Giới tính không được để trống")
    private Gender gender;

    @NotNull(message = "Ngày hết hạn của CCCD không được để trống")
    private LocalDate dateOfExpiry;

    @NotNull(message = "Phương thức xác thực thông tin không được để trống")
    private IdentityMethod identityMethod;
}
