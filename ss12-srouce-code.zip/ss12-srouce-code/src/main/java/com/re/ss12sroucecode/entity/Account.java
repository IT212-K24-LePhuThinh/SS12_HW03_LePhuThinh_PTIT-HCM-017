package com.re.ss12sroucecode.entity;

import com.re.ss12sroucecode.enums.Gender;
import com.re.ss12sroucecode.enums.IdentityMethod;
import com.re.ss12sroucecode.enums.KycStatus;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Thực thể Account đại diện cho thông tin tài khoản đăng ký và tiến trình eKYC của khách hàng.
 * Tệp dữ liệu nhạy cảm được cấu hình ràng buộc unique để tránh trùng lặp dữ liệu trên hệ thống.
 */
@Entity
@Table(name = "accounts", indexes = {
    @Index(name = "idx_accounts_phone", columnList = "phone"),
    @Index(name = "idx_accounts_email", columnList = "email"),
    @Index(name = "idx_accounts_citizen_id", columnList = "citizenId")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Số điện thoại đăng ký (Module 1 - Duy nhất)
     */
    @Column(name = "phone", unique = true, nullable = false, length = 15)
    private String phone;

    /**
     * Địa chỉ Email (Module 1 - Duy nhất)
     */
    @Column(name = "email", unique = true, nullable = false, length = 100)
    private String email;

    /**
     * Mã OTP được tạo phục vụ xác thực (Module 1)
     */
    @Column(name = "otp_code", length = 6)
    private String otpCode;

    /**
     * Thời gian hết hạn OTP (Module 1)
     */
    @Column(name = "otp_expiry")
    private LocalDateTime otpExpiry;

    /**
     * Số lần nhập sai OTP liên tiếp (Khóa sau 3 lần - Module 1)
     */
    @Column(name = "otp_retry_count", nullable = false)
    @Builder.Default
    private Integer otpRetryCount = 0;

    /**
     * Số định danh cá nhân / Số CCCD 12 chữ số (Module 2 - Duy nhất)
     */
    @Column(name = "citizen_id", unique = true, length = 12)
    private String citizenId;

    /**
     * Họ và tên đầy đủ trích xuất từ CCCD (Module 2)
     */
    @Column(name = "full_name", length = 150)
    private String fullName;

    /**
     * Ngày sinh trích xuất từ CCCD (Module 2)
     */
    @Column(name = "date_of_birth")
    private LocalDate dateOfBirth;

    /**
     * Giới tính trích xuất từ CCCD (Module 2)
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "gender", length = 10)
    private Gender gender;

    /**
     * Ngày hết hạn của CCCD (Module 2)
     */
    @Column(name = "date_of_expiry")
    private LocalDate dateOfExpiry;

    /**
     * Phương thức xác thực thông tin CCCD (NFC hoặc OCR dự phòng)
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "identity_method", length = 10)
    private IdentityMethod identityMethod;

    /**
     * Trạng thái xác thực chữ ký số CA từ Bộ Công An (Module 2)
     */
    @Column(name = "nfc_ca_valid")
    private Boolean nfcCaValid;

    /**
     * Trạng thái xác thực thực thể sống khuôn mặt (Module 3)
     */
    @Column(name = "liveness_passed")
    private Boolean livenessPassed;

    /**
     * Tỷ lệ tương đồng khuôn mặt (%) so với ảnh CCCD (Module 3)
     */
    @Column(name = "face_match_percentage")
    private Double faceMatchPercentage;

    /**
     * Trạng thái tiến trình eKYC (Module 4)
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private KycStatus status;

    /**
     * Mã số CIF định danh duy nhất trên Core Banking (Module 4)
     */
    @Column(name = "cif_number", unique = true, length = 10)
    private String cifNumber;

    /**
     * Số tài khoản thanh toán được cấp (Module 4)
     */
    @Column(name = "account_number", unique = true, length = 15)
    private String accountNumber;

    /**
     * Trạng thái tra cứu AML/PEP (CLEAR / FAILED)
     */
    @Column(name = "aml_status", length = 10)
    private String amlStatus;

    /**
     * Thời gian bị khóa tạm thời (ví dụ: khóa đăng ký 24h hoặc 7 ngày)
     */
    @Column(name = "blocked_until")
    private LocalDateTime blockedUntil;

    /**
     * Thời gian tạo bản ghi
     */
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    /**
     * Thời gian cập nhật bản ghi
     */
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        if (this.status == null) {
            this.status = KycStatus.INITIATED;
        }
        if (this.otpRetryCount == null) {
            this.otpRetryCount = 0;
        }
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
