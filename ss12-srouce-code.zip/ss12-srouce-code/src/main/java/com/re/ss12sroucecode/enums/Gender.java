package com.re.ss12sroucecode.enums;

/**
 * Giới tính của khách hàng.
 */
public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
