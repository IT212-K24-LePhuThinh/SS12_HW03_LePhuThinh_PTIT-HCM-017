package com.re.ss12sroucecode.enums;

/**
 * Phương thức xác thực thông tin giấy tờ tùy thân (CCCD).
 */
public enum IdentityMethod {
    /**
     * Quét chip qua NFC (Luồng tối ưu có bảo mật cao nhất).
     */
    NFC,

    /**
     * Chụp ảnh và trích xuất dữ liệu bằng công nghệ OCR (Luồng dự phòng khi không có NFC).
     */
    OCR
}
