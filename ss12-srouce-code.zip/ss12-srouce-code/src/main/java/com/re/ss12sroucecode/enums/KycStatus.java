package com.re.ss12sroucecode.enums;

/**
 * Trạng thái của tiến trình định danh khách hàng (eKYC).
 */
public enum KycStatus {
    /**
     * Khởi tạo đăng ký (nhập SĐT/Email).
     */
    INITIATED,

    /**
     * Đã xác thực OTP thành công.
     */
    OTP_VERIFIED,

    /**
     * Đã đọc và xác thực CCCD (NFC/OCR) thành công.
     */
    IDENTITY_VERIFIED,

    /**
     * eKYC hoàn tất, đã phê duyệt tự động mở tài khoản (STP Rate 100%).
     */
    APPROVED,

    /**
     * eKYC bị từ chối.
     */
    REJECTED,

    /**
     * eKYC bị khóa do các dấu hiệu gian lận hoặc nhập sai quá nhiều lần.
     */
    BLOCKED
}
