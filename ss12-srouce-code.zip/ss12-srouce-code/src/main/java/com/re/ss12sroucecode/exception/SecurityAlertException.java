package com.re.ss12sroucecode.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Ngoại lệ xảy ra khi phát hiện các vấn đề vi phạm bảo mật nghiêm trọng (như chữ ký số không hợp lệ, giả mạo khuôn mặt).
 */
@ResponseStatus(HttpStatus.FORBIDDEN)
public class SecurityAlertException extends RuntimeException {
    public SecurityAlertException(String message) {
        super(message);
    }
}
