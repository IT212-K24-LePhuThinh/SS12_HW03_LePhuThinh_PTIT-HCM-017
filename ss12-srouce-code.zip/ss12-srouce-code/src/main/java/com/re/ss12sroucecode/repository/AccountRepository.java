package com.re.ss12sroucecode.repository;

import com.re.ss12sroucecode.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository xử lý các thao tác dữ liệu với thực thể Account.
 * Sử dụng JPQL tối ưu hóa việc kiểm tra trùng lặp thông tin.
 */
@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {

    /**
     * Tìm tài khoản theo số điện thoại.
     */
    Optional<Account> findByPhone(String phone);

    /**
     * Tìm tài khoản theo email.
     */
    Optional<Account> findByEmail(String email);

    /**
     * Tìm tài khoản theo số CCCD.
     */
    Optional<Account> findByCitizenId(String citizenId);

    /**
     * Truy vấn JPQL tối ưu kiểm tra trùng lặp Số điện thoại hoặc Email hoặc Số căn cước công dân.
     * Trả về true nếu phát hiện bất cứ trường thông tin nào đã tồn tại trong hệ thống.
     */
    @Query("SELECT COUNT(a) > 0 FROM Account a WHERE a.phone = :phone OR a.email = :email OR (:citizenId IS NOT NULL AND a.citizenId = :citizenId)")
    boolean existsByPhoneOrEmailOrCitizenId(
        @Param("phone") String phone,
        @Param("email") String email,
        @Param("citizenId") String citizenId
    );

    /**
     * Kiểm tra trùng điện thoại hoặc email ngoại trừ ID hiện tại (khi thực hiện cập nhật tiến trình).
     */
    @Query("SELECT COUNT(a) > 0 FROM Account a WHERE (a.phone = :phone OR a.email = :email) AND a.id <> :id")
    boolean existsByPhoneOrEmailExcludeId(
        @Param("phone") String phone,
        @Param("email") String email,
        @Param("id") Long id
    );

    /**
     * Kiểm tra trùng Citizen ID ngoại trừ ID hiện tại.
     */
    @Query("SELECT COUNT(a) > 0 FROM Account a WHERE a.citizenId = :citizenId AND a.id <> :id")
    boolean existsByCitizenIdExcludeId(
        @Param("citizenId") String citizenId,
        @Param("id") Long id
    );
}
