package com.re.ss12sroucecode.service;

import com.re.ss12sroucecode.dto.*;

/**
 * Service interface định nghĩa các nghiệp vụ xử lý luồng eKYC 4 bước của ABC Bank.
 */
public interface AccountService {

    /**
     * Bước 1: Khởi tạo đăng ký thông tin liên lạc (SĐT, Email), gửi mã OTP.
     * @param request DTO chứa Số điện thoại và Email.
     * @return DTO phản hồi tiến trình đăng ký.
     */
    AccountRegistrationResponse initiateRegistration(AccountRegistrationRequest request);

    /**
     * Bước 1 (Tiếp tục): Xác thực mã OTP của khách hàng.
     * @param request DTO chứa Số điện thoại và mã OTP nhập vào.
     * @return DTO phản hồi trạng thái xác thực.
     */
    AccountRegistrationResponse verifyOtp(OtpVerificationRequest request);

    /**
     * Bước 2: Upload thông tin giấy tờ tùy thân (CCCD) và quét NFC/OCR.
     * @param request DTO chứa thông tin trích xuất từ CCCD.
     * @return DTO phản hồi trạng thái xác thực giấy tờ.
     */
    AccountRegistrationResponse verifyIdentity(IdentityVerificationRequest request);

    /**
     * Bước 3 & Bước 4: Xác thực sinh trắc học khuôn mặt và tự động kích hoạt tài khoản Core Banking (STP).
     * @param request DTO chứa ảnh khuôn mặt sinh trắc học và các tham số kiểm thử.
     * @return DTO phản hồi hoàn thành mở tài khoản thành công.
     */
    AccountRegistrationResponse verifyBiometric(BiometricVerificationRequest request);

    /**
     * Tra cứu trạng thái đăng ký của tài khoản.
     * @param id ID của tài khoản trong hệ thống.
     * @return DTO chứa thông tin trạng thái tài khoản.
     */
    AccountRegistrationResponse getAccountStatus(Long id);
}
