package com.re.ss12sroucecode.service;

import com.re.ss12sroucecode.dto.*;
import com.re.ss12sroucecode.entity.Account;
import com.re.ss12sroucecode.enums.IdentityMethod;
import com.re.ss12sroucecode.enums.KycStatus;
import com.re.ss12sroucecode.exception.*;
import com.re.ss12sroucecode.repository.AccountRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.Optional;
import java.util.Random;

/**
 * Lớp triển khai các nghiệp vụ eKYC của ABC Bank.
 * Xử lý tuần tự 4 Module, tự động hóa Straight-Through Processing (STP) và tích hợp giả lập.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final Random random = new Random();

    /**
     * BƯỚC 1: Khởi tạo thông tin liên lạc và gửi mã OTP.
     * Độ phức tạp thuật toán: O(1) do truy vấn tìm kiếm theo chỉ mục cơ sở dữ liệu (Index).
     */
    @Override
    @Transactional
    public AccountRegistrationResponse initiateRegistration(AccountRegistrationRequest request) {
        String phone = request.getPhone();
        String email = request.getEmail();

        log.info("Bắt đầu khởi tạo đăng ký eKYC cho SĐT: {}, Email: {}", phone, email);

        // Kiểm tra trùng lặp Số điện thoại hoặc Email trên hệ thống
        Optional<Account> existingByPhone = accountRepository.findByPhone(phone);
        Optional<Account> existingByEmail = accountRepository.findByEmail(email);

        if (existingByPhone.isPresent()) {
            Account acc = existingByPhone.get();
            // Nếu tài khoản đã hoàn thành phê duyệt mở tài khoản
            if (acc.getStatus() == KycStatus.APPROVED) {
                throw new DuplicateResourceException("Số điện thoại này đã được đăng ký và kích hoạt tài khoản thành công");
            }
            // Nếu tài khoản đang bị khóa tạm thời
            if (acc.getBlockedUntil() != null && acc.getBlockedUntil().isAfter(LocalDateTime.now())) {
                throw new BadRequestException("Số điện thoại này đang bị khóa tạm thời. Vui lòng thử lại sau: " + acc.getBlockedUntil());
            }
        }

        if (existingByEmail.isPresent()) {
            Account acc = existingByEmail.get();
            if (acc.getStatus() == KycStatus.APPROVED) {
                throw new DuplicateResourceException("Địa chỉ email này đã được sử dụng cho một tài khoản khác");
            }
        }

        // Tạo mã OTP gồm 6 chữ số ngẫu nhiên
        String otpCode = String.format("%06d", random.nextInt(1000000));
        
        // Test hook: nếu số điện thoại kết thúc bằng 123, gán cứng OTP để dễ kiểm thử tự động
        if (phone.endsWith("123")) {
            otpCode = "123456";
        }
        
        LocalDateTime otpExpiry = LocalDateTime.now().plusSeconds(180); // Hiệu lực 180 giây theo SRS

        Account account;
        if (existingByPhone.isPresent()) {
            // Tái sử dụng phiên đăng ký chưa hoàn thành để tránh lãng phí bản ghi
            account = existingByPhone.get();
            account.setEmail(email);
            account.setOtpCode(otpCode);
            account.setOtpExpiry(otpExpiry);
            account.setOtpRetryCount(0); // Reset số lần thử OTP
            account.setStatus(KycStatus.INITIATED);
            log.info("Cập nhật phiên đăng ký hiện có cho SĐT: {}. Mã OTP mới: {}", phone, otpCode);
        } else {
            // Tạo mới bản ghi phiên đăng ký eKYC
            account = Account.builder()
                    .phone(phone)
                    .email(email)
                    .otpCode(otpCode)
                    .otpExpiry(otpExpiry)
                    .otpRetryCount(0)
                    .status(KycStatus.INITIATED)
                    .build();
            log.info("Tạo mới phiên đăng ký eKYC cho SĐT: {}. Mã OTP: {}", phone, otpCode);
        }

        accountRepository.save(account);

        // Giả lập gửi OTP qua SMS Gateway
        log.info("[SMS GATEWAY] Gửi tin nhắn SMS tới SĐT {}: Ma OTP xac thuc eKYC cua quy khach la {}. Hieu luc trong 180 giay.", phone, otpCode);

        return AccountRegistrationResponse.builder()
                .id(account.getId())
                .phone(phone)
                .email(email)
                .status(account.getStatus())
                .message("Mã OTP đã được gửi tới số điện thoại đăng ký. Vui lòng xác thực trong 180 giây.")
                .build();
    }

    /**
     * BƯỚC 1 (Tiếp tục): Xác thực mã OTP.
     * Độ phức tạp thuật toán: O(1) qua tìm kiếm SĐT.
     */
    @Override
    @Transactional(noRollbackFor = {BadRequestException.class, SecurityAlertException.class})
    public AccountRegistrationResponse verifyOtp(OtpVerificationRequest request) {
        String phone = request.getPhone();
        String otpCode = request.getOtpCode();

        log.info("Thực hiện xác thực OTP cho SĐT: {}", phone);

        Account account = accountRepository.findByPhone(phone)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy phiên đăng ký cho số điện thoại này"));

        // Kiểm tra xem tài khoản có bị khóa không
        if (account.getBlockedUntil() != null && account.getBlockedUntil().isAfter(LocalDateTime.now())) {
            throw new BadRequestException("Số điện thoại này đang bị khóa đăng ký. Vui lòng thử lại sau: " + account.getBlockedUntil());
        }

        // Kiểm tra xem trạng thái tài khoản có hợp lệ để xác thực OTP không
        if (account.getStatus() == KycStatus.APPROVED) {
            throw new BadRequestException("Tài khoản đã hoàn tất eKYC và được kích hoạt trước đó");
        }

        // Kiểm tra OTP hết hạn sử dụng
        if (LocalDateTime.now().isAfter(account.getOtpExpiry())) {
            throw new BadRequestException("Mã OTP đã hết hạn sử dụng. Vui lòng yêu cầu gửi lại OTP.");
        }

        // Đối chiếu mã OTP
        if (!account.getOtpCode().equals(otpCode)) {
            int retries = account.getOtpRetryCount() + 1;
            account.setOtpRetryCount(retries);

            if (retries >= 3) {
                // Khóa đăng ký trong vòng 24 giờ do nhập sai quá 3 lần liên tiếp
                account.setStatus(KycStatus.BLOCKED);
                account.setBlockedUntil(LocalDateTime.now().plusDays(1));
                accountRepository.save(account);
                log.warn("SĐT {} bị khóa 24 giờ do nhập sai OTP quá 3 lần", phone);
                throw new SecurityAlertException("Mã OTP không chính xác. Quý khách đã nhập sai quá 3 lần. Số điện thoại đăng ký này bị khóa trong 24 giờ.");
            } else {
                accountRepository.save(account);
                throw new BadRequestException("Mã OTP không chính xác. Số lần thử còn lại: " + (3 - retries) + "/3");
            }
        }

        // Xác thực thành công
        account.setStatus(KycStatus.OTP_VERIFIED);
        account.setOtpRetryCount(0); // Reset bộ đếm nhập sai
        accountRepository.save(account);

        log.info("Xác thực OTP thành công cho SĐT: {}. Chuyển sang bước quét CCCD.", phone);

        return AccountRegistrationResponse.builder()
                .id(account.getId())
                .phone(account.getPhone())
                .email(account.getEmail())
                .status(account.getStatus())
                .message("Xác thực số điện thoại thành công. Vui lòng tiếp tục bước quét thẻ căn cước công dân (CCCD).")
                .build();
    }

    /**
     * BƯỚC 2: Quét thẻ CCCD (NFC / OCR Verification).
     * Độ phức tạp thuật toán: O(1) kiểm tra ràng buộc duy nhất và lưu thông tin.
     */
    @Override
    @Transactional(noRollbackFor = {SecurityAlertException.class})
    public AccountRegistrationResponse verifyIdentity(IdentityVerificationRequest request) {
        String phone = request.getPhone();
        String citizenId = request.getCitizenId();

        log.info("Bắt đầu xử lý dữ liệu CCCD cho SĐT: {}, Số định danh: {}", phone, citizenId);

        Account account = accountRepository.findByPhone(phone)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy phiên đăng ký cho số điện thoại này"));

        // Kiểm tra xem đã vượt qua bước OTP chưa
        if (account.getStatus() != KycStatus.OTP_VERIFIED && account.getStatus() != KycStatus.IDENTITY_VERIFIED) {
            throw new BadRequestException("Phiên đăng ký chưa hoàn tất xác thực OTP. Không thể thực hiện bước này.");
        }

        // Kiểm tra trùng lặp Số CCCD với tài khoản khác trong hệ thống (Tránh mở nhiều tài khoản cùng CCCD)
        boolean isCitizenIdDuplicate = accountRepository.existsByCitizenIdExcludeId(citizenId, account.getId());
        if (isCitizenIdDuplicate) {
            // Kiểm tra xem tài khoản trùng lặp đó đã APPROVED hay chưa
            Optional<Account> duplicateAcc = accountRepository.findByCitizenId(citizenId);
            if (duplicateAcc.isPresent() && duplicateAcc.get().getStatus() == KycStatus.APPROVED) {
                throw new DuplicateResourceException("Số định danh cá nhân (CCCD) này đã được sử dụng để mở tài khoản trên hệ thống");
            }
        }

        // Kiểm tra hạn sử dụng của CCCD (Không chấp nhận giấy tờ hết hạn)
        if (request.getDateOfExpiry().isBefore(LocalDate.now())) {
            throw new BadRequestException("Giấy tờ tùy thân của quý khách đã hết hạn sử dụng. Vui lòng sử dụng giấy tờ còn hiệu lực.");
        }

        // Kiểm tra chữ ký số CA từ Bộ Công An nếu thực hiện quét chip NFC
        if (request.getIdentityMethod() == IdentityMethod.NFC) {
            // Test hook: nếu số CCCD bắt đầu bằng "999", giả lập kết quả xác thực chữ ký CA thất bại
            if (citizenId.startsWith("999")) {
                account.setStatus(KycStatus.REJECTED);
                accountRepository.save(account);
                log.error("CẢNH BÁO GIẢ MẠO: Xác thực chữ ký số CA của chip thất bại (CA INVALID) đối với SĐT: {}", phone);
                throw new SecurityAlertException("Không thể xác thực thông tin giấy tờ trực tuyến (CA INVALID). Vui lòng liên hệ quầy giao dịch gần nhất.");
            }
            account.setNfcCaValid(true);
            log.info("Xác thực chữ ký số CA của chip NFC thành công thông qua kết nối C06 (VALID)");
        } else {
            // Luồng dự phòng OCR chụp ảnh
            account.setNfcCaValid(false);
            log.warn("Thiết bị không hỗ trợ NFC hoặc Quét NFC thất bại. Chuyển sang luồng OCR dự phòng với hạn mức thấp cho SĐT: {}", phone);
        }

        // Lưu trữ thông tin CCCD vào cơ sở dữ liệu
        account.setCitizenId(citizenId);
        account.setFullName(request.getFullName());
        account.setDateOfBirth(request.getDateOfBirth());
        account.setGender(request.getGender());
        account.setDateOfExpiry(request.getDateOfExpiry());
        account.setIdentityMethod(request.getIdentityMethod());
        account.setStatus(KycStatus.IDENTITY_VERIFIED);

        accountRepository.save(account);

        log.info("Lưu trữ thông tin định danh thành công cho SĐT: {}. Chuyển sang bước xác thực khuôn mặt.", phone);

        return AccountRegistrationResponse.builder()
                .id(account.getId())
                .phone(account.getPhone())
                .email(account.getEmail())
                .status(account.getStatus())
                .citizenId(account.getCitizenId())
                .fullName(account.getFullName())
                .identityMethod(account.getIdentityMethod().name())
                .message("Đọc dữ liệu giấy tờ tùy thân thành công. Vui lòng tiếp tục bước chụp khuôn mặt để so khớp sinh trắc học.")
                .build();
    }

    /**
     * BƯỚC 3 & 4: Xác thực sinh trắc học khuôn mặt và Phê duyệt STP tự động kích hoạt tài khoản.
     * Độ phức tạp thuật toán: O(1) xử lý logic nghiệp vụ và cập nhật Core Banking.
     */
    @Override
    @Transactional(noRollbackFor = {SecurityAlertException.class, BadRequestException.class})
    public AccountRegistrationResponse verifyBiometric(BiometricVerificationRequest request) {
        String phone = request.getPhone();

        log.info("Bắt đầu xử lý sinh trắc học khuôn mặt cho SĐT: {}", phone);

        Account account = accountRepository.findByPhone(phone)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy phiên đăng ký cho số điện thoại này"));

        // Kiểm tra xem đã hoàn thành bước CCCD chưa
        if (account.getStatus() != KycStatus.IDENTITY_VERIFIED) {
            throw new BadRequestException("Phiên đăng ký chưa hoàn tất xác thực thông tin giấy tờ tùy thân. Không thể thực hiện bước này.");
        }

        // Kiểm tra xem tài khoản có bị khóa không
        if (account.getBlockedUntil() != null && account.getBlockedUntil().isAfter(LocalDateTime.now())) {
            throw new BadRequestException("Phiên đăng ký này đang bị khóa. Vui lòng thử lại sau.");
        }

        // 1. Kiểm tra thực thể sống (Liveness Check)
        boolean livenessPassed = true;
        if (request.getMockLivenessPassed() != null) {
            livenessPassed = request.getMockLivenessPassed();
        } else {
            // Mock logic: nếu chuỗi ảnh Base64 chứa "MOCK_FAIL_LIVENESS", giả lập phát hiện tấn công giả mạo
            if (request.getFaceImageBase64().contains("MOCK_FAIL_LIVENESS")) {
                livenessPassed = false;
            }
        }

        if (!livenessPassed) {
            // Ghi nhận thiết bị/IP vào Blacklist và khóa đăng ký trong 7 ngày
            account.setStatus(KycStatus.BLOCKED);
            account.setBlockedUntil(LocalDateTime.now().plusDays(7));
            accountRepository.save(account);
            log.error("CẢNH BÁO BẢO MẬT: Phát hiện tấn công sinh trắc học giả mạo (Liveness Check FAIL) trên SĐT: {}", phone);
            throw new SecurityAlertException("Phát hiện giả mạo khuôn mặt (Liveness Check FAIL). Phiên đăng ký của quý khách bị chặn trong 7 ngày.");
        }

        account.setLivenessPassed(true);

        // 2. So khớp khuôn mặt (Face Matching) với ảnh gốc trích xuất từ CCCD
        double faceMatchPercentage = 92.5; // Mặc định khớp cao
        if (request.getMockFaceMatchPercentage() != null) {
            faceMatchPercentage = request.getMockFaceMatchPercentage();
        } else {
            // Mock logic: nếu chuỗi ảnh Base64 chứa "MOCK_LOW_MATCH", giả lập tỷ lệ khớp thấp
            if (request.getFaceImageBase64().contains("MOCK_LOW_MATCH")) {
                faceMatchPercentage = 75.0;
            }
        }

        account.setFaceMatchPercentage(faceMatchPercentage);

        // Kiểm tra ngưỡng tương đồng theo quy định của ngân hàng (>= 85.00%)
        if (faceMatchPercentage < 85.0) {
            accountRepository.save(account);
            log.warn("Xác thực khuôn mặt thất bại cho SĐT: {}. Độ tương đồng: {}% < 85%", phone, faceMatchPercentage);
            throw new BadRequestException(String.format("Khuôn mặt chụp thực tế không khớp với ảnh trên giấy tờ tùy thân. Tỷ lệ tương đồng chỉ đạt %.2f%% (yêu cầu tối thiểu 85.00%%). Vui lòng chụp lại.", faceMatchPercentage));
        }

        log.info("Xác thực sinh trắc học thành công. Độ tương đồng đạt: {}% >= 85%", faceMatchPercentage);

        // BƯỚC 4: KÍCH HOẠT TÀI KHOẢN (RULE ENGINE PHÊ DUYỆT STP & CORE BANKING INTEGRATION)
        log.info("Kích hoạt quy trình phê duyệt tự động STP cho khách hàng: {}", account.getFullName());

        // Kiểm tra độ tuổi (Phải từ 18 tuổi trở lên)
        int age = Period.between(account.getDateOfBirth(), LocalDate.now()).getYears();
        if (age < 18) {
            account.setStatus(KycStatus.REJECTED);
            accountRepository.save(account);
            log.warn("Từ chối phê duyệt tự động do khách hàng chưa đủ 18 tuổi. Tuổi thực tế: {}", age);
            throw new BadRequestException("Yêu cầu bị từ chối do quý khách chưa đủ 18 tuổi để mở tài khoản trực tuyến.");
        }

        // Kiểm tra hệ thống danh sách đen AML/Blacklist và PEP (Giả lập)
        String fullName = account.getFullName().toUpperCase();
        String citizenId = account.getCitizenId();
        
        // Quy tắc giả lập kiểm tra Blacklist/Sanctions
        if (fullName.contains("MOCK BLACKLIST") || citizenId.startsWith("000")) {
            account.setStatus(KycStatus.REJECTED);
            account.setAmlStatus("FAILED");
            accountRepository.save(account);
            log.error("AML SCREENING FAIL: Số căn cước {} trùng khớp danh sách đen phòng chống rửa tiền", citizenId);
            throw new BadRequestException("Do quy định phòng chống rửa tiền, yêu cầu mở tài khoản trực tuyến của bạn chưa thể thực hiện. Vui lòng mang giấy tờ tùy thân ra quầy giao dịch ABC Bank gần nhất để được phục vụ.");
        }

        // Quy tắc giả lập kiểm tra PEP (Người có tầm ảnh hưởng chính trị)
        if (fullName.contains("MOCK PEP") || citizenId.startsWith("111")) {
            account.setStatus(KycStatus.REJECTED);
            account.setAmlStatus("PEP_MATCH");
            accountRepository.save(account);
            log.warn("PEP SCREENING MATCH: Khách hàng thuộc danh sách PEP. Từ chối phê duyệt STP.");
            throw new BadRequestException("Do quy định phòng chống rửa tiền, yêu cầu mở tài khoản trực tuyến của bạn chưa thể thực hiện. Vui lòng mang giấy tờ tùy thân ra quầy giao dịch ABC Bank gần nhất để được phục vụ.");
        }

        account.setAmlStatus("CLEAR");

        // Gọi API Core Banking tạo mã CIF và Số tài khoản thanh toán mới (Giả lập)
        String cifNumber = "CIF" + String.format("%07d", random.nextInt(10000000));
        String accountNumber = "100" + String.format("%09d", random.nextLong(1000000000L));

        account.setCifNumber(cifNumber);
        account.setAccountNumber(accountNumber);
        account.setStatus(KycStatus.APPROVED);

        accountRepository.save(account);

        log.info("Phê duyệt tự động hoàn tất (STP Rate 100%). Cấp mã CIF: {}, Số tài khoản: {}", cifNumber, accountNumber);

        // Giả lập gửi SMS mật khẩu tạm thời
        log.info("[SMS GATEWAY] Gửi tin nhắn SMS tới SĐT {}: Chuc mung quy khach mo tai khoan thanh cong! So tai khoan: {}. Mat khau dang nhap ung dung tam thoi cua quy khach la: ABCBank@{}", 
                phone, accountNumber, random.nextInt(9000) + 1000);

        String responseMessage = String.format("Chúc mừng %s đã đăng ký mở tài khoản eKYC thành công! Hạn mức giao dịch của bạn là: %s.",
                account.getFullName(),
                account.getIdentityMethod() == IdentityMethod.NFC ? "Không giới hạn" : "Tối đa 10,000,000 VND/tháng");

        return AccountRegistrationResponse.builder()
                .id(account.getId())
                .phone(account.getPhone())
                .email(account.getEmail())
                .status(account.getStatus())
                .citizenId(account.getCitizenId())
                .fullName(account.getFullName())
                .identityMethod(account.getIdentityMethod().name())
                .livenessPassed(account.getLivenessPassed())
                .faceMatchPercentage(account.getFaceMatchPercentage())
                .amlStatus(account.getAmlStatus())
                .cifNumber(account.getCifNumber())
                .accountNumber(account.getAccountNumber())
                .message(responseMessage)
                .build();
    }

    /**
     * Tra cứu trạng thái đăng ký của tài khoản.
     * Độ phức tạp thuật toán: O(1) qua tìm kiếm ID.
     */
    @Override
    @Transactional(readOnly = true)
    public AccountRegistrationResponse getAccountStatus(Long id) {
        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy tài khoản với ID: " + id));

        return AccountRegistrationResponse.builder()
                .id(account.getId())
                .phone(account.getPhone())
                .email(account.getEmail())
                .status(account.getStatus())
                .citizenId(account.getCitizenId())
                .fullName(account.getFullName())
                .identityMethod(account.getIdentityMethod() != null ? account.getIdentityMethod().name() : null)
                .livenessPassed(account.getLivenessPassed())
                .faceMatchPercentage(account.getFaceMatchPercentage())
                .amlStatus(account.getAmlStatus())
                .cifNumber(account.getCifNumber())
                .accountNumber(account.getAccountNumber())
                .message("Trạng thái hiện tại của tài khoản: " + account.getStatus())
                .build();
    }
}
